function L=ecooling(varargin)
% ECOOLING  Electron cooling rates
%
% L = ECOOLING(...)
%
% Cooling rate L is in W m^-3
%
% Andrew Senior, Lancaster University, 2010.
% $Id: ecooling.m 115 2010-08-03 08:46:45Z senior $

e=1.602e-19; % electron charge (C)

n2vib_p98_P1=[ 7.252e-15 -9.562e-11 2.954e-7 8.782e-4 2.025;
              -2.449e-14 4.436e-10 -3.066e-6 1.001e-2 -7.066;
              -2.706e-14 4.891e-10 -3.369e-6 1.092e-2 -8.211;
              -3.008e-14 5.431e-10 -3.732e-6 1.204e-2 -9.713;
              -3.100e-14 5.600e-10 -3.850e-6 1.243e-2 -10.353;
              -2.936e-14 5.385e-10 -3.771e-6 1.244e-2 -10.819;
              -2.769e-14 5.086e-10 -3.570e-6 1.185e-2 -10.183];
n2vib_p98_P2=[-5.479e-12 2.439e-8 -4.075e-5 3.151e-2 -6.462];

n2vib_c04_P=[ -6.859584e-28  2.072139e-23  -2.647034e-19  1.854619e-15 ...
              -7.718809e-12  1.928050e-8   -2.788177e-5   2.232010e-2  ...
             -20.53338;
              -7.197135e-29  2.951543e-24  -5.059731e-20  4.793986e-16 ...
              -2.775980e-12  1.019910e-8   -2.377044e-5   3.381645e-2  ...
             -34.26962;
               0             7.646298e-25  -2.228996e-20  2.767044e-16 ...
              -1.906802e-12  7.963622e-9   -2.061168e-5   3.222374e-2  ...
             -35.48243;
               5.076359e-28 -1.440022e-23   1.706720e-19 -1.085827e-15 ...
               3.917439e-12 -7.431033e-9    3.925376e-6   1.058009e-2  ...
             -27.15243;
               7.458488e-28 -2.216591e-23   2.790345e-19 -1.929100e-15 ...
               7.907546e-12 -1.913251e-8    2.452598e-5  -8.916443e-3  ...
             -20.53292;
               0             6.091531e-25  -1.834737e-20  2.362236e-16 ...
              -1.695386e-12  7.406585e-9   -2.012980e-5   3.307371e-2  ...
             -37.82919;
               0             5.310360e-25  -1.613160e-20  2.096600e-16 ...
              -1.520620e-12  6.722730e-9   -1.852920e-5   3.100290e-2  ...
             -36.86810;
               0             0             -1.637750e-21  4.435710e-17 ...
              -5.032050e-13  3.094860e-9   -1.112690e-5   2.329070e-2  ...
             -34.52000;
               0             0             -1.241880e-21  3.470410e-17 ...
              -4.077370e-13  2.608400e-9   -9.804670e-6   2.160660e-2  ...
             -34.44360;
               0             0              0             4.025500e-18 ...
              -9.909600e-14  9.974600e-10  -5.250400e-6   1.519400e-2  ...
             -31.65800];

par=cell2struct(varargin(2:2:end),varargin(1:2:end),2);

switch par.process
  case 'n2rot_sn78'
    % N2 rotational excitation
    % from SN78 (Schunk & Nagy, Rev. Geophys. Space Phys., 16, 355 (1978)).
    L=2.9e-14*par.n_e.*par.n_N2.*(par.T_e-par.T_n)./par.T_e.^0.5;
    L=L*1e-6*e;
  case 'n2rot_p98'
    % N2 rotational excitation
    % from P98
    % Note that this is just a correction factor to the SN78
    % formula (multiply by 1.255)
    L=3.6e-14*par.n_e.*par.n_N2.*(par.T_e-par.T_n)./par.T_e.^0.5;
    L=L*1e-6*e;    
  case 'o2rot_sn78'
    % O2 rotational excitation
    % from SN78
    L=6.9e-14*par.n_e.*par.n_O2.*(par.T_e-par.T_n)./par.T_e.^0.5;
    L=L*1e-6*e;
  case 'o2rot_p98'
    % O2 rotational excitation
    % from P98 (Pavlov, Ann. Geophys., 16, 1007, (1998))
    L=5.2e-15*par.n_e.*par.n_O2.*(par.T_e-par.T_n)./par.T_e.^0.5;
    L=L*1e-6*e;
  case 'n2vib_sn78'
    % N2 vibrational excitation
    % from SN78
    f=1.06e4+7.51e3*tanh(1.10e-3*(par.T_e-1800));
    g=3300+1.233*(par.T_e-1000)-2.056e-4*(par.T_e-1000).*(par.T_e-4000);
    L=2.99e-12*par.n_e.*par.n_N2.*exp(f.*(par.T_e-2000)./(2000*par.T_e)) ...
      .*(1-exp(-g.*(par.T_e-par.T_n)./(par.T_e.*par.T_n)));
    L=L*1e-6*e;
  case {'n2vib_p98','n2vib_p98_corr'}
    % N2 vibrational excitation
    % from P98 (Pavlov, Ann. Geophys, 16, 176 (1998))
    L=zeros(size(par.T_e));
    k=find(par.T_e>1500);
    for n=1:7
      L(k)=L(k)+10.^(polyval(n2vib_p98_P1(n,:),par.T_e(k))-16) ...
           .*(1-exp(n*3353*(1./par.T_e(k)-1./par.T_n)));
    end
    k=find(par.T_e<=1500);
    L(k)=10.^(polyval(n2vib_p98_P2,par.T_e(k))-16) ...
         .*(1-exp(3353*(1./par.T_e(k)-1./par.T_n)));
    L=L.*par.n_e.*par.n_N2.*(1-exp(-3353./par.T_n));
    L=L*1e-6*e;
    
    if strcmp(par.process,'n2vib_p98_corr')
      % correction derived from Bjorn's Monte-Carlo stuff
      c=-2.8802e-4*par.T_e+1.4353;
      c(par.T_e < 1500)=1;
      L=c.*L;
    end

  case 'n2vib_c04'
    % N2 vibrational excitation
    % from C04 (Campbell et al. (2004), Planet. Space Sci. 52,
    % 815).
    % The cooling rates from Table 1/Eq. (4) are used in Pavlov's
    % expression.
    L=zeros(size(par.T_e));
    for n=1:size(n2vib_c04_P,1)
      L=L+10.^(polyval(n2vib_c04_P(n,:),par.T_e)) ...
           .*(1-exp(n*3353*(1./par.T_e-1./par.T_n)));
    end
    L=L.*par.n_e.*par.n_N2.*(1-exp(-3353./par.T_n));
    L=L*1e-6*e;    
    
  case 'o2vib_sn78'
    % O2 vibrational excitation
    % from SN78
    h=3300-839*sin(1.91e-4*(par.T_e-2700));
    L=5.196e-13*par.n_e.*par.n_O2.*exp(h.*(par.T_e-700)./(700*par.T_e)) ...
      .*(1-exp(-2770*(par.T_e-par.T_n)./(par.T_e.*par.T_n)));
    L=L*1e-6*e;
  case 'o2vib_p98'
    % O2 vibrational excitation
    % from P98
    Q=8.8e-15*exp((1-304./par.T_e).*(10.2+0.4*sin(1.083e-3*(par.T_e-1000))));
    L=par.n_e.*par.n_O2.*Q.*(1-exp(2239*(1./par.T_e-1./par.T_n)));
    L=L*1e-6*e;
  case 'o2vib_j03'
    % O2 vibrational excitation
    % from J03 (Jones et al., New J. Phys., 5, 114.1, 2003)
    %
    % NB: we use only the "total" transfer rate here and use it in
    % the formula (10) of Pavlov, 1998 (AG 16 1007).
    %
    % The "total" transfer rate is valid for 300 <= Te <= 6000 K
    QT=10.^(polyval(fliplr([-19.9171 0.0267 -3.996e-5 3.5187e-8 -1.9228e-11 ...
                    6.6865e-15 -1.4791e-18 2.0127e-22 -1.5346e-26 ...
                    5.0148e-31]),par.T_e));
    L=par.n_e.*par.n_O2.*QT.*(1-exp(2239*(1./par.T_e-1./par.T_n)));
    L=L*1e-6*e;
  case 'n2elast_sn78'
    % Elastic collisions with N2
    % from Schunk & Nagy (1978)
    L=1.77e-19*par.n_e.*par.n_N2.*(1-1.21e-4*par.T_e).*par.T_e ...
      .*(par.T_e-par.T_n);
    L=L*1e-6*e;
  otherwise
    error(['unknown process: ' par.process]);
end


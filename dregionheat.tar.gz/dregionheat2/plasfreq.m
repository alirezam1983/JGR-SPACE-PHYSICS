function wp=plasfreq(ne)
% PLASFREQ  Calculate angular plasma frequency from electron density
%
% WP = PLASFREQ(NE)
%
% NE is electron density in m^-3, WP is plasma frequency in rad/s
%
% Andrew Senior, Lancaster University, 2010.
% $Id: plasfreq.m 116 2010-08-03 08:48:27Z senior $

wp=(ne*(1.602e-19)^2)/(8.854e-12*9.110e-31);
wp=wp.^0.5;

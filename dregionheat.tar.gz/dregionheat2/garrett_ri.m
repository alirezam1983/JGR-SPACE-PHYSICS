function [mu,D,mu_test]=garrett_ri(om,om_p,om_H,th,OorX,n_N2,n_O2,n_O,T)
% GARRETT_RI  Generalized magnetoionic refractive index
%
% [mu,D] = garrett_ri(om,om_p,om_H,th,OorX,n_N2,n_O2,n_O,T)
%
% Gives the magnetoionic refractive index according to the
% generalized theory of Garrett (1985), J. Plasma Phys., 33,
% 265. Only electrons are included.
%
% om, om_p, om_H: the angular wave, plasma and gyro frequencies
%                 respectively.
% th: angle between direction of phase propagation and magnetic
%     field
% OorX: 1 for O-mode, -1 for X-mode
% n_N2, n_O2, n_O: number densities (m^-3) of N2, O2 and
%                  O. (Currently O is ignored).
% T: electron temperature (K)
%
% ALL INPUT ARGUMENTS MUST BE THE SAME SIZE, except that om_p,
% om_H, th and OorX can be scalars when the other arguments are not.
%
% mu is the complex refractive index; D is the "discriminant" in
% the Garrett formula.
%
% NB: it is not clear if the O/X mode selection works properly in general.
%
% Andrew Senior, Lancaster University, 2010.
% $Id: garrett_ri.m 115 2010-08-03 08:46:45Z senior $

% Check argument sizes

args={n_N2,n_O2,n_O,T};

for k=2:length(args)
  if ndims(args{k}) ~= ndims(args{k-1})
    error('Input arguments must be the same size!');
  end
  if numel(args{k}) ~= numel(args{k-1})
    error('Input arguments must be the same size!');
  end
end

clear args

sz=size(T);

args={om,om_p,om_H,th,OorX};

for k=1:length(args)
  if ~all(size(args{k}) == [1 1]) ...
     & ~all(size(args{k}) == sz)
     error('Input argument size error');
  end
end

clear args

% If om is passed as a scalar, expand it to the same size as the
% non-scalar arguments.

if all(size(om) == [1 1])
  om=om*ones(sz);
end

% Constants

me=9.109e-31;
q=1.602e-19;
kB=1.381e-23;

% Dimensionless variables

X=(om_p./om).^2;
Y=om_H./om;

% Evaluate the PI functions

PI1=zeros(size(T));
PI2=zeros(size(T));
PI3=zeros(size(T));

E_max=10; % maximum energy for cross-section integration
r_tol=1e-3; % relative error tolerances for integration
i_tol=1e-3;

for k=1:numel(T)
  PI1(k)=pi_integral(T(k),(1+Y(k)).*om(k),n_N2(k),n_O2(k),E_max,r_tol,i_tol);
  PI2(k)=pi_integral(T(k),(1-Y(k)).*om(k),n_N2(k),n_O2(k),E_max,r_tol,i_tol);
  PI3(k)=pi_integral(T(k),om(k),n_N2(k),n_O2(k),E_max,r_tol,i_tol);
end 

PI1=PI1./(1+Y);
PI2=PI2./(1-Y);

% Parameters in the dispersion relation (Eq. 48 of Garrett)

A=0.5.*X.*(PI1+PI2);
B=0.5.*X.*(PI1+PI2-2*PI3);
G=0.5.*X.*(PI1-PI2);

s=sin(th).^2;
c=cos(th).^2;

D=G.^2.*c+0.25*((B-A.*B+G.^2)./(1-A+B)).^2.*s.^2;

eta=A-0.5*((B+A.*B-G.^2)./(1-A+B)).*s ...
    +OorX.*sign(angle(D)).*sqrt(D);

eta=eta./(A.^2-G.^2-(A.*B-G.^2)./(1-A+B).*s);

mu=sqrt(1-1./eta);

% Using Eq. 71:
mu2=1-(A.*B-G.^2)./B;
mu2=mu2-G.^2.*(G.^2-B.^2)./(B.*G.^2-0.5*((B-A.*B+G.^2)./(1-A+B)).*B.^2.*s ...
                            +OorX.*sign(angle(D)).*B.^2.*sqrt(D));


mu_test=sqrt(mu2);

% Integral transform (Eq. 45 of Garrett)

% Relies on integrating the definition Eq. B1 of
% Garrett by parts and observing that cross sections tend to
% diminish rapidly to zero at high energies. The result removes the
% need for the differentiation, except that we need the derivative
% of the Maxwellian distribution instead.
%
% The integration is performed with respect to dimensionless speed and
% incorporates a procedure to first estimate the value of the
% integrals and set appropriate error limits on the integration.

function [I,I_est]=pi_integral(Te,l,N2,O2,E_max,r_tol,i_tol)

me=9.109e-31;
q=1.602e-19;
kB=1.381e-23;

vs=sqrt(kB*Te/me); % characteristic speed

% First get rough (often quite good) estimates of the
% integrals. This is done by knowing that the integral of the
% weighting function from zero to infinity is 3*sqrt(pi/2) and by
% assuming that the rest of the integrand is a constant, equal to
% its value at twice the characteristic speed (vs) which is where
% the weighting function peaks

W=collfreq(2*vs,N2,O2);
Ir_est=3*sqrt(pi/2)/(1+(W/l).^2);
Ii_est=3*sqrt(pi/2)*(W/l)/(1+(W/l).^2);

% Use the estimates to define the appropriate absolute error
% tolerance on the numerical integration, to get the desired
% relative tolerances

r_tol=Ir_est*r_tol;
i_tol=Ii_est*i_tol;

% The upper limit of the integration, in dimensionless speed, is
% either 10 or the dimensionless speed corresponding to the maximum
% allowed energy, whichever is smaller

v_max=sqrt(2*E_max*q/me);
u_max=min([10 v_max/vs]);

if u_max < 7
  warning('Upper limit of integration may be too low');
end

% Do the numerical integrations

Ir=quad(@(u) r_integrand(u,vs,l,N2,O2),1e-3,u_max,r_tol,0);
Ii=quad(@(u) i_integrand(u,vs,l,N2,O2),1e-3,u_max,i_tol,0);

% Apply final scale factors

a=-(1/(2*pi))^1.5;
a=a*-4*pi/3;

Ir=Ir*a;
Ii=Ii*a;
Ir_est=Ir_est*a;
Ii_est=Ii_est*a;

I=Ir+i*Ii;
I_est=Ir_est+i*Ii_est;

function I=r_integrand(u,vs,l,n_N2,n_O2)

F=u.^4.*exp(-0.5*u.^2);
W=collfreq(u*vs,n_N2,n_O2);
re_0=1./(1+(W/l).^2);
I=F.*re_0;

function I=i_integrand(u,vs,l,n_N2,n_O2)

F=u.^4.*exp(-0.5*u.^2);
W=collfreq(u*vs,n_N2,n_O2);
im_0=(W/l)./(1+(W/l).^2);
I=F.*im_0;


function W=collfreq(v,n_N2,n_O2)

me=9.109e-31;
q=1.602e-19;

E=0.5*me.*v.^2./q; % Energy in eV
W=v.*(n_N2*enmtcs('N2_tabmorr',E)+n_O2*enmtcs('O2',E));
%W=v.*n_N2.*enmtcs('Stubbe_sim',E);





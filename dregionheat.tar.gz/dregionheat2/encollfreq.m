function nu_en=encollfreq(varargin)
% ENCOLLFREQ  Electron-neutral collision frequency
%
% NU = ENCOLLFREQ(...)
%
% Inputs are name/value pairs:
%
% method     Method to use:
%            'sn78' (default) = Schunk & Nagy, 1978
% T_e        Electron temperature (K)
% n_N2       N2 concentration (m^-3)
% n_O2       O2 concentration (m^-3)
% n_O        O concentration (m^-3)
%
% Andrew Senior, Lancaster University, 2010.
% $Id: encollfreq.m 126 2010-08-03 08:53:34Z senior $

par=cell2struct(varargin(2:2:end),varargin(1:2:end),2);
if ~isfield(par,'method')
  par.method='sn78'; % calculation method
end

n_N2=par.n_N2;
n_O2=par.n_O2;
n_O=par.n_O;
T_e=par.T_e;

switch par.method
 case 'sn78' % Schunk and Nagy, 1978
  nu_en=2.33e-17.*n_N2.*(1-1.21e-4.*T_e).*T_e ...
        +1.82e-16.*n_O2.*(1+3.6e-2.*sqrt(T_e)).*sqrt(T_e) ...
        +8.9e-17.*n_O.*(1+5.7e-4.*T_e).*sqrt(T_e);
 otherwise
  error(['Unknown method "' par.method '"']);
end


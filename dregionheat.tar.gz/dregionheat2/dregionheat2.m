function [z,t,Te,J]=dregionheat2(varargin)
% DREGIONHEAT2  D-region radio heating model
%
% [z,t,Te,J] = dregionheat2(...)
%
% Calculates the time-dependent electron temperature and heater
% power-flux profiles resulting from a rectangular radio heating
% pulse incident on the D-region.
%
% Input parameters are name/value pairs:
%
% ERP         Heater effective isotropic radiated power (W)
% om          Heater angular frequency (rad/s)
% heat_OorX   1 = O-mode polarisation, -1 = X-mode
% om_H        Angular gyrofrequency (rad/s)
% t_heat      Length of heater pulse (s)
% t_max       Time limit of model calculation
% t_step      Output time step (NOT USED)
% ri_method   Refractive index calculation method. Options are:
%             'AH' - Appleton-Hartree, phase propagation parallel
%               to magnetic field
%             'garrett' - Garrett's generalized formula, phase
%               propagation parallel to magnetic field
% equilibrium Flag. Non-zero means calculate equilibrium profiles
%             only.
% cool_model  Electron cooling model. Options are:
%             'standard' - standard configuration
%             'standard_c04' - as standard, but with Campbell et
%               al. (2004) cooling rate for N2 vibrations 
%             'Stubbe' - cooling rates used in Stubbe's model
% za          Zenith angle of incident wave (radians)
% Ne          Electron density profile (m^-3)
% z_Ne        Altitudes of the data in Ne (m)
% n_O         Atomic oxygen concentration profile (m^-3) at heights
%             in z_Ne
% n_O2        As above, but molecular oxygen
% n_N2        As above, but molecular nitrogen
% Tn          Neutral temperature profile (K)
% plot        Flag - non-zero to enable plotting
%
% If any of n_O, n_O2, n_N2 or Tn are not specified, the following
% parameters are required so that MSIS can be called to provide the
% missing information:
%
% lat         Geographic latitude (degrees north)
% long        Geographic longitude (degrees east)
% f107a       3-month mean F10.7 (see msis.m)
% f107p       Previous day's F10.7 (see msis.m)
% ap          Daily Ap index (see msis.m)
% UTC         UTC date/time vector: [year month day hr min sec]
%
% Outputs:
%
% z           The vector of altitudes (m)
% t           Cell array of times (s), containing one vector for each
%             altitude layer at which the temperature and power
%             flux have been calculated
% Te          Cell array of electron temperatures (K), one vector
%              for each altitude layer.
% J           Cell array of heater power fluxes (W/m^2), one vector
%             for each altitude layer. Note that these values are only provided
%             for times during the heater pulse.
%
% In equilibrium mode, t is a scalar with no meaning and Te and J
% are simple vectors, giving the altitude profiles of temperature
% and power flux in the equilibrium state.
%
% Andrew Senior, Lancaster University, 2010
% $Id: dregionheat2.m 114 2010-08-03 08:40:53Z senior $

% constants

kB=1.381e-23; % Boltzmann constant
eps0=8.854e-12; % permittivity of free space
m=9.109e-31; % electron mass
c=299792458; % speed of light
e=1.602e-19; % electron charge

% parameters

par.ERP=605e6; % heater E(I)RP (W)
par.om=2*pi*5.423e6; % heater frequency
par.heat_OorX=-1; % 1 = O-mode, -1 = X-mode  
par.om_H=2*pi*1.4e6; % electron gyrofrequency
par.lat=69.58;
par.long=19.22;
par.f107a=80;
par.f107p=66.1; % 2008-06-28
par.ap=7; % 2008-06-28
par.UTC=[2005 6 28 10 0 0]; % NB: note year is not correct!
par.t_heat=50e-6; % heater pulse length
par.t_max=500e-6; % limit of time domain
par.t_step=1e-6; % step size of time "grid"

par.ri_method='AH'; % method of calculating radio refractive index
par.equilibrium=0; % non-zero means find only equilibrium
                   % temperatures
par.cool_model='standard'; % electron cooling model
par.za=0; % zenith angle (radians)

par.Ne=[];
par.z_Ne=[];

par.n_O=[]; % neutral densities (m^-3)
par.n_O2=[];
par.n_N2=[];
par.Tn=[]; % neutral temperature (K)

par.plot=1; % non-zero to enable plotting

par=processnvargs(par,varargin);

% electron density

if ~isempty(par.Ne)
  % use profile if given...
  Ne=par.Ne(:);
  z=par.z_Ne;
else
  % ... otherwise get one from IRI
  z=(65:0.3:90)*1e3;
  [Ne,Te,Ti,Tn,NO,NH,NHe,NO2,NNO]=iri(par.UTC,par.lat,par.long,z/1e3);
end

r=z/cos(par.za); % range to each altitude

dz=diff(z);
dr=diff(r);

% initial heater power flux (Wm^-2)
J0=par.ERP/(4*pi*r(1)^2);
fprintf(' Power flux at lowest altitude = %.1f mW/m^2\n',J0*1e3);

% if any of the neutral atmosphere parameters are missing, call
% MSIS

if isempty(par.n_O) || isempty(par.n_O2) || isempty(par.n_N2) ...
    || isempty(par.Tn)
  
  % neutral densities and temperature from MSIS

  [He,O,N2,O2,Ar,Mass,H,N,Tex,Tn]=msis(par.UTC,z/1e3,par.lat,par.long, ...
                                       par.f107a,par.f107p,par.ap);

  % convert densities to m^-3
  O=O*1e6;
  O2=O2*1e6;
  N2=N2*1e6;

end

% if user has specified density or temperature profiles, use them
% in place of MSIS

if ~isempty(par.n_O); O=par.n_O; end
if ~isempty(par.n_O2); O2=par.n_O2; end
if ~isempty(par.n_N2); N2=par.n_N2; end
if ~isempty(par.Tn); Tn=par.Tn; end

if par.equilibrium
  Te=[];
  t=[];
  J=[];
else
  Te={};
  t={};
  J={};
end

if ~par.equilibrium && par.plot
  figure
end

if ~par.equilibrium && ~par.plot
  wbh=waitbar(0,'Solving...');
end

for k=1:length(z)-1
  
  % solve the equation

  if par.equilibrium
    hfunc=@eqm_hflux;
    tJ=[];
  elseif k==1
    % initial layer, so use unabsorbed heater flux
    hfunc=@hflux;
    tJ=[];
  else
    % use heater flux from previous layer
    hfunc=@hfluxinterp;
  end
    

  if par.equilibrium
    % find equilibrium temperature

    Te_sol=eqm_Te(par.om,par.om_H,par.heat_OorX,Ne(k), ...
              Tn(k),O(k),N2(k),O2(k),hfunc,J0,par.ri_method, ...
              par.cool_model);
    t_sol=0;
    Te(k)=Te_sol;
    t(k)=t_sol;
     
  else
    % solve time-dependent problem
 
    if ~par.plot
      waitbar(k/(length(z)-1),wbh,['Layer ' num2str(k)]);
    end
      
    opt=odeset('abstol',1e-1,'reltol',1e-4);
    
    sol1=ode113(@tefunc,[0 par.t_heat],Tn(k),opt,par.om, ...
                par.om_H,par.heat_OorX,Ne(k), ...
                Tn(k),O(k),N2(k),O2(k),hfunc,J0,tJ,par.ri_method, ...
                par.cool_model);
    
    sol2=ode113(@tefunc,[par.t_heat par.t_max],sol1.y(end),opt,par.om, ...
                par.om_H,par.heat_OorX,Ne(k), ...
                Tn(k),O(k),N2(k),O2(k),@noheatfunc,J0,tJ, ...
                par.ri_method,par.cool_model);

    Te_sol=[sol1.y sol2.y(2:end)];
    Te{k}=Te_sol;
    t_sol=[sol1.x sol2.x(2:end)];
    t{k}=t_sol;
    
  end
  
  %%%% Find heater power flux out of layer %%%%
  
  j=find(t_sol <= par.t_heat);
  J0=feval(hfunc,t_sol(j),J0,tJ);
  
  J1=(r(k)/(r(k)+dr(k)))^2*J0; % beam divergence
  
  % Power flux lost due to the heating
  % Only need to calculate this during the heater pulse!
  
  n_pts=length(j);
  
  J_loss=2*J0.*dr(k).* ...
         -imag(emwavenum(par.ri_method,par.om,plasfreq(Ne(k)),par.om_H, ...
                         par.heat_OorX, ...
                         O(k)*ones(1,n_pts),O2(k)*ones(1,n_pts), ...
                         N2(k)*ones(1,n_pts),Te_sol(j)));
 
  J1=J1-J_loss;

  
  % If any power fluxes have gone negative, this means we've
  % overestimated the absorption because the layer is too
  % thick. Just set them to zero.
  
  if(any(J1 < 0))
    warning('Layer too thick for rate of attenuation');
  end
  J1(J1 < 0)=0;
  
  if par.equilibrium
    J(k)=J1;
  else
    J{k}=J1;
  end
  
  tJ=t_sol(j); % remember heater flux and time steps for next layer
  J0=J1;
  
  if ~par.equilibrium & par.plot
  
    subplot(2,1,1)
    plot(sol1.x,sol1.y,'ro-',sol2.x,sol2.y,'bo-')
    xlim([0 par.t_max]);
    ylabel('T_e (K)');
    title(sprintf('Altitude = %.1f km',z(k)/1e3));
    
    subplot(2,1,2)
    plot(tJ,J1*1e3,'k');
    xlim([0 par.t_max]);
    ylabel('Output power flux (mW m^{-2})');
    
  end
  
  drawnow;
  
end

if par.equilibrium
  fprintf(' Power flux at top of model = %.3f mW/m^2\n',J1*1e3);
end

if ~par.equilibrium && ~par.plot; delete(wbh); end

if par.equilibrium & par.plot
  figure
  plot(Te,z(1:end-1)/1e3);
end

if par.equilibrium
  return; % finish here for equilibrium case
end

% grid the data for plotting

t_grid2=0:dr(1)/c:par.t_max;
Te_grid=repmat(nan,length(z)-1,length(t_grid2));

for k=1:length(z)-1
  % when interpolating, also correct for propagation delay between layers
  if k>1
    dt=sum(dr(1:k-1))/c;
  else
    dt=0;
  end

  Te_grid(k,:)=interp1(t{k}+dt,Te{k},t_grid2,'pchip',nan);
end

if par.plot
  figure
  contourf(t_grid2/1e-3,z(1:end-1)/1e3,Te_grid);
  colorbar
  xlabel('Time (ms)');
  ylabel('Altitude (km)');
  zlabel('T_e (K)');

  % Lines to show propagation of heater pulse
  t0=[0 par.t_heat];
  t1=t0+(z(end)-z(1))/(c*cos(par.za));
  line([t0; t1]/1e-3,[z(1) z(1); z(end) z(end)]/1e3,'color','w');
  line([t0; t1]/1e-3,[z(1) z(1); z(end) z(end)]/1e3, ...
    'color','k','linestyle','--');
end

% solve for equilibrium electron temperature
% Binary search

function Te=eqm_Te(om,om_H,OorX,Ne,Tn,O,N2,O2,hfunc,J0,ri_method,cool_model)

delta_Te=1;
Te=[Tn 4000];

f0=tefunc(0,Te(1),om,om_H,OorX,Ne,Tn,O,N2,O2,hfunc,J0,[],ri_method, ...
          cool_model);
f1=tefunc(0,Te(2),om,om_H,OorX,Ne,Tn,O,N2,O2,hfunc,J0,[],ri_method, ...
          cool_model);

k=0;
while 1
  k=k+1;
  if f0*f1>0
    % (Probably) no solution in this interval
    error('apparently no solution in interval');
    Te=NaN; 
    return;
  end
  mid_Te=0.5*(Te(1)+Te(2));
  fm=tefunc(0,mid_Te,om,om_H,OorX,Ne,Tn,O,N2,O2,hfunc,J0,[],ri_method, ...
            cool_model);
  if f0*fm<=0
    Te=[Te(1) mid_Te];
    f1=fm;
  elseif f1*fm<=0
    Te=[mid_Te Te(2)];
    f0=fm;
  else
    error('something has gone wrong!');
  end
  if (Te(2)-Te(1))<=delta_Te
    % solution found with required accuracy
    Te=0.5*(Te(1)+Te(2));
    return;
  end
end
  
% differential equation for electron temperature

function dTe=tefunc(t,Te,om,om_H,OorX,Ne,Tn,O,N2,O2,fluxfunc,J0,tJ, ...
                    ri_method,cool_model)

% constants

kB=1.381e-23; % Boltzmann constant

if Ne~=0

  % source
  J=feval(fluxfunc,t,J0,tJ);
  Q=J*2*-imag(emwavenum(ri_method,om,plasfreq(Ne),om_H,OorX,O,O2,N2,Te));
  
  % loss
  
  switch cool_model
    case {'standard','standard_c04'}
  
      L=ecooling('process','n2rot_p98','n_N2',N2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
      if strcmp(cool_model,'standard_c04')
        L=L+ecooling('process','n2vib_c04', ...
                     'n_N2',N2,'T_e',Te,'T_n',Tn,'n_e',Ne);        
      else
        L=L+ecooling('process','n2vib_p98', ...
                     'n_N2',N2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      end
      
      L=L+ecooling('process','o2vib_j03', ...
                   'n_O2',O2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
      L=L+ecooling('process','o2rot_p98', ...
                   'n_O2',O2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
    case 'Stubbe'

      % Cooling model used in Stubbe's code
      
      L=ecooling('process','n2rot_sn78','n_N2',N2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
      L=L+ecooling('process','n2vib_sn78', ...
                   'n_N2',N2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
      L=L+ecooling('process','o2vib_sn78', ...
                   'n_O2',O2,'T_e',Te,'T_n',Tn,'n_e',Ne);
      
      L=L+ecooling('process','o2rot_sn78', ...
                   'n_O2',O2,'T_e',Te,'T_n',Tn,'n_e',Ne);      
  
    case 'test'
      
      L=1e-9*(Te-Tn);
  
  end
  
  dTe=2*(Q-L)/(3*kB*Ne);

else
  
  dTe=0;

end

% heater power flux function

function J=hflux(t,J0,tJ)

J=J0*ones(size(t));

% heater power flux from previous layer

function J=hfluxinterp(t,J0,tJ)

% Interpolate power flux. Return zero if outside domain.
J=interp1(tJ,J0,t,'pchip',0);

% null heating function

function J=noheatfunc(t,J0,tJ)

J=zeros(size(t));

% constant flux for equilibrium calculations

function J=eqm_hflux(t,J0,tJ)

J=J0*ones(size(t));

% process name/value arguments

function out=processnvargs(def,inp)

out=def; % copy default arguments

nargs=length(inp)/2;
if mod(nargs,1) ~= 0
  error('Arguments must be name/value pairs');
end

for k=1:nargs
  argname=inp{k*2-1};
  if ~ischar(argname)
    error('Arguments must be name/value pairs');
  end
  
  if ~isfield(def,argname)
    % Ignore arguments for which we don't have a default
    warning('Argument ''%s'' ignored',argname);
  else
    % Override default with input argument
    out.(argname)=inp{k*2};
  end
end

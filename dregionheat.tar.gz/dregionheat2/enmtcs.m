function s=enmtcs(species,E)
% ENMTCS  Electron-neutral momentum transfer cross-sections
%
% S = EMNTCS(species,E)
%
% 'species' selects the neutral species and method used, E is a
% vector of energies in eV. S is a corresponding vector of
% cross-sections in m^2.
%
% 'species' can be:
%
% N2 - composite curve for N2
% N2_tabata - analytical formula for N2 from Tabata et al.
% N2_morrison - analytical formula for N2 from Morrison et al. (E <
% 1.25 eV)
% O2 - composite curve for O2
%
% Andrew Senior, Lancaster University, 2010.
% $Id: enmtcs.m 115 2010-08-03 08:46:45Z senior $

% N2, from Sun et al. (1995), Phys. Rev. A, 52, 1229, quoted by
% Brunger & Buckman (2002), Phys. Rep., 357, 215.

persistent pp_N2 pp_O2

s_N2=[0.55  10.68;
      1.0   10.78;
      1.5   11.12;
      1.92  17.40;
      1.98  18.03;
      2.46  16.65;
      2.61  12.38;
      4     9.64;
      5     8.64;
      6     8.29;
      7     8.31;
      8     8.53;
      10    8.40];
  
% O2, from Sullivan et al. (1995), J. Phys. B, 28, 4319. for E >
% 1eV. Below 1 eV, the data are  from Lawton & Phelps (1978),
% J. Chem. Phys., 69, 1055. See
% ftp://jila.colorado.edu/collision_data/electronneutral/electron.txt 

s_O2=[0.0000        0.3500
      0.0010        0.3500
      0.0020        0.3600
      0.0030        0.4000
      0.0050        0.5000
      0.0070        0.5800
      0.0085        0.6400
      0.0100        0.7000
      0.0150        0.8700
      0.0200        0.9900
      0.0300        1.2400
      0.0400        1.4400
      0.0500        1.6000
      0.0700        2.1000
      0.1000        2.5000
      0.1200        2.8000
      0.1500        3.1000
      0.1700        3.3000
      0.2000        3.6000
      0.2500        4.1000
      0.3000        4.5000
      0.3500        4.7000
      0.4000        5.2000
      0.5000        5.7000
      0.7000        6.1000
      1     6.7;
      2     6.5;
      3     6.1;
      4     6.0;
      5     5.7;
      7     5.7;
      8     6.2;
      9     5.9;
      10    6.4;
      15    5.9;
      20    6.1;
      30    6.0];

if isempty(pp_O2)
    pp_O2=interp1(s_O2(:,1),s_O2(:,2),'linear','pp');
end
  
switch species
  case 'N2_tabata'
    s=n2_tabata(E);
  case 'N2_tabata2'
    s=n2_tabata2(E);
  case 'N2'
    % For energies above 0.55 eV, use the table
    j=find(E>=0.55);
    s(j)=1e-20*interp1(s_N2(:,1),s_N2(:,2),E(j),'cubic',nan);  
    % For energies in the range 0.01 to 0.55 eV, use Tabata's formula
    j=find((E >= 0.01) & (E < 0.55));
    s(j)=n2_tabata(E(j));
    % For energies below 0.01 eV, use Morrison's formula
    j=find(E < 0.01);
    s(j)=n2_morrison(E(j));
  case 'N2_tabmorr'
    % For energies below 0.01 eV, use Morrison's formula
    j=find(E < 0.01);
    s(j)=n2_morrison(E(j)); 
    % For energies above 0.01, use Tabata's formula
    j=find(E >= 0.01);
    s(j)=n2_tabata(E(j)); 
  case 'N2_morrison'
    s=n2_morrison(E);
  case 'O2'
    %s=1e-20*interp1(s_O2(:,1),s_O2(:,2),E,'linear',nan);
    s=1e-20*ppval(pp_O2,E);
  case 'Stubbe_sim'
    % Simulate collision frequency model used in Stubbe's D-region
    % heating code.
    %s=1.06e-17*(1/(3*1.38e-23))*sqrt(2*E*1.602e-19*9.109e-31);
    s=1.06e-17*(1/(1.38e-23))*sqrt(E*1.602e-19*9.109e-31/2);
end

function s=n2_morrison(E)
% Analytic form for E < 1.25 eV from Morrison et
% al. (1997), Phys. Rev. A, 55. 2786.
s=2.2167+29.2988*E.^0.5-44.6748*E.*log(E)-20.3865*E ...
  +25.4971*E.^2;
s=s*2.8003e-21; % Morrison gives s in units of (Bohr radius)^2.

function s=n2_tabata(E)

% Analytic form from Tabata et al (2006), At. Data and Nucl. Data
% Tabs., 92, 375-406. Based on Itikawa et al. (1986),
% J. Phys. Chem. Ref. Data, 15, 985-1010.

s=f3(E/1e3,1.370e2,5.820e-1,4.010e-4,1.280e-1,9.290e-3,1.545e0) ...
  +f2(E/1e3,1.960e7,7.820e0,2.370e-3,5.870e0);

function s=n2_tabata2(E)

% Analytic form from Tabata et al (2006), At. Data and Nucl. Data
% Tabs., 92, 375-406. Based on Itikawa et al. (1986),
% J. Phys. Chem. Ref. Data, 15, 985-1010.

% Modified to add Morrison's constant term

s=f3(E/1e3,1.370e2,5.820e-1,4.010e-4,1.280e-1,9.290e-3,1.545e0) ...
  +f2(E/1e3,1.960e7,7.820e0,2.370e-3,5.870e0);
s=s+2.2167*2.8003e-21;

% Functions used in the Tabata et al. expressions

function y=f1(x,c1,c2)

y=1e-20*c1*(x/1.361e-2).^c2;

function y=f2(x,c1,c2,c3,c4)

y=f1(x,c1,c2)./(1+(x/c3).^(c2+c4));

function y=f3(x,c1,c2,c3,c4,c5,c6)

y=f1(x,c1,c2)./(1+(x/c3).^(c2+c4)+(x/c5).^(c2+c6));

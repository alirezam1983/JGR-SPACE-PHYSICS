function k=emwavenum(method,om,om_p,om_H,OorX,n_O,n_O2,n_N2,Te)
% EMWAVENUM  Complex wavenumber of EM wave in plasma
%
% A utility function to calculate the complex wavenumber of an EM
% wave in a plasma.
%
% k = emwavenum(method,om,om_p,om_H,OorX,n_O,n_O2,n_N2,Te)
%
% method is 'AH' for Appleton-Hartree, assuming phase propagation
% parallel to the magnetic field or 'garrett' for Garrett's
% generalised refractive index, again assuming parallel
% propagation.
%
% Other inputs:
%
% om        Angular wave frequency (rad/s)
% om_p      Angular plasma frequency (rad/s)
% om_H      Angular electron gyrofrequency (rad/s)
% OorX      1 = O-mode, -1 = X-mode
% n_O       O concentration (m^-3)
% n_O2      O2 concentration (m^-3)
% n_N2      N2 concentration (m^-3)
% Te        Electron temperature (K)
%
% Andrew Senior, Lancaster University, 2010.
% $Id: emwavenum.m 117 2010-08-03 09:10:21Z senior $

c=299792458; % speed of light

if om_H < 0
  warning('negative gyrofrequency detected!');
end

switch method
    
  case 'AH'

    % Full Appleton-Hartree for phase propagation parallel to B
    
    nu=encollfreq('T_e',Te,'n_O',n_O,'n_O2',n_O2,'n_N2',n_N2);
    
    X=(om_p./om).^2;
    Y=om_H./om;
    Z=nu./om;
    
    n=1-X./(1-i*Z+OorX*Y);
    n=sqrt(n);
    
  case 'garrett'
    
    % Garrett's generalized refractive index
   
    n=garrett_ri(om,om_p,om_H,0,OorX,n_N2,n_O2,n_O,Te);
    
end

k=om.*n/c;

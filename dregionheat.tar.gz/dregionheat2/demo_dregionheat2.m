function demo_dregionheat2
% DEMO_DREGIONHEAT2  Demonstration of use of DREGIONHEAT2
%
% This function performs a demonstration run of DREGIONHEAT2 using
% neutral atmosphere data read from a file (atmos.mat) and an
% electron density profile that is constant above 90 km and
% decreases exponentially below this height.
%
% The function calls DREGIONHEAT2 to model the electron temperature
% increase due to radio heating and then uses this to calculate the
% absorption and phase shift of a diagnostic wave passing through
% the heated ionosphere.
%
% Andrew Senior, Lancaster University, 2010.
% $Id: demo_dregionheat2.m 118 2010-08-03 09:14:53Z senior $

% Parameters
f_diag=7.953e6; % HF radar frequency
max_int_alt=85e3; % upper altitude limit of diagnostic absorption integration

% Load neutral atmosphere table

atm=load('atmos.mat');

% Electron density profile

Ne=1e10*exp((atm.alt-90)/4.3);
Ne(atm.alt > 90)=1e10;
Ne=Ne(:);

figure
subplot(2,2,1)
semilogx(Ne,atm.alt);
xlabel('N_e (m^{-3})');
ylabel('Altitude (km)');


% Convert MSIS neutral densities to m^-3
O=atm.O*1e6;
O2=atm.O2*1e6;
N2=atm.N2*1e6;

[z,t,Te,J]= ...
    dregionheat2('z_Ne',atm.alt*1e3,'Ne',Ne,'ERP',400e6, ...
                'om',2*pi*5.423e6,'heat_OorX',-1, ...
                'plot',0,'equilibrium',1,'n_O',O,'n_O2',O2,'n_N2',N2, ...
                 'Tn',atm.T);


subplot(2,2,3)
plot(Te,z(1:end-1)/1e3);
xlabel('T_e (K)');
ylabel('Altitude (km)');

% unheated absorption

k0_O=emwavenum('AH',2*pi*f_diag,plasfreq(Ne), ...
               2*pi*1.4e6,1,O,O2,N2,atm.T);
k0_X=emwavenum('AH',2*pi*f_diag,plasfreq(Ne), ...
               2*pi*1.4e6,-1,O,O2,N2,atm.T);


% heated absorption
k1_O=emwavenum('AH',2*pi*f_diag,plasfreq(Ne(1:end-1)), ...
           2*pi*1.4e6,1,O(1:end-1),O2(1:end-1),N2(1:end-1),Te.');
k1_X=emwavenum('AH',2*pi*f_diag,plasfreq(Ne(1:end-1)), ...
           2*pi*1.4e6,-1,O(1:end-1),O2(1:end-1),N2(1:end-1),Te.');


subplot(2,2,4)
plot(-20*log10(exp(1))*1e3*imag(k1_O-k0_O(1:end-1)),z(1:end-1)/1e3,'b', ...
     -20*log10(exp(1))*1e3*imag(k1_X-k0_X(1:end-1)),z(1:end-1)/1e3,'r');
xlabel('Absorption change (dB km^{-1})');
ylabel('Altitude (km)');

fprintf('\n Upper limit of integration = %.1f km\n',max_int_alt/1e3);

j=find(z <= max_int_alt);

K0_O=trapz(z(j),k0_O(j));
K1_O=trapz(z(j),k1_O(j));
K0_X=trapz(z(j),k0_X(j));
K1_X=trapz(z(j),k1_X(j));

fprintf('           Absorption    Phase\n');
fprintf('           O      X      O        X\n');
fprintf(' Unheated: %6.3f %6.3f %8.3f %8.3f\n', ...
        -20*log10(exp(1))*imag(K0_O),-20*log10(exp(1))*imag(K0_X), ...
        real(K0_O),real(K0_X));
fprintf('   Heated: %6.3f %6.3f %8.3f %8.3f\n', ...
        -20*log10(exp(1))*imag(K1_O),-20*log10(exp(1))*imag(K1_X), ...
        real(K1_O),real(K1_X));



